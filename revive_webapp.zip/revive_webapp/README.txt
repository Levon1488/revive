PROJEKT REVIVE – web app (static + PWA)
=======================================

Co je uvnitř
------------
- index.html  … váš finální dokument upravený pro web
- manifest.json … PWA manifest (název, barvy, ikony)
- sw.js … service worker (cache pro offline zobrazení)
- /icons … ikony pro instalaci (nahraďte vlastními 192/512px)

Jak to spustit lokálně
----------------------
1) Otevřete terminál ve složce tohoto projektu.
2) Spusťte lokální server (vyberte jednu variantu):
   - Python:  python -m http.server 5173
   - Node:    npx http-server -p 5173
3) V prohlížeči otevřete: http://localhost:5173

Nasazení (Vercel/Netlify/GitHub Pages)
--------------------------------------
- Vercel: `vercel` v kořeni složky (detekuje statický projekt).
- Netlify: přetáhněte složku do Netlify Drop nebo propojte repo.
- GitHub Pages: nahrajte do repozitáře, v Settings → Pages zvolte branch.

Poznámky
--------
- PWA běží jen přes HTTPS nebo localhost.
- Pokud používáte relativní cesty na obrázky/fonty, zůstanou funkční po nasazení.